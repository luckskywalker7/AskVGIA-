// ========== ASKVGIA Dashboard JS ==========

// --- Tab switching (Dashboard) ---
const tabs = document.querySelectorAll('.tab');
const tabPanels = document.querySelectorAll('.tab-panel');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    tabPanels.forEach(panel => panel.classList.remove('active'));
    const target = tab.dataset.tab;
    const targetPanel = document.getElementById(target);
    if (targetPanel) targetPanel.classList.add('active');
  });
});

// --- Suggested question cards click -> fill textarea ---
const questionCards = document.querySelectorAll('.question-card');
const textarea = document.getElementById('ask-textarea');

questionCards.forEach(card => {
  card.addEventListener('click', () => {
    const question = card.dataset.question || card.querySelector('.q-text').innerText.trim();
    if (textarea) {
      textarea.value = question;
      textarea.focus();
    }
  });
});

// Send button and textarea are handled by api.js (uses IDs: ask-send-btn, ask-textarea)

// --- User dropdown toggle ---
const userMenu = document.getElementById('user-menu');
const userDropdown = document.getElementById('user-dropdown');

if (userMenu && userDropdown) {
  userMenu.addEventListener('click', (e) => {
    e.stopPropagation();
    userDropdown.classList.toggle('open');
  });

  document.addEventListener('click', () => {
    userDropdown.classList.remove('open');
  });
}

// --- Dark/Light mode toggle ---
const themeToggle = document.getElementById('theme-toggle');
let isDark = true;

if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    isDark = !isDark;
    const icon = themeToggle.querySelector('i');
    if (isDark) {
      document.body.classList.remove('light-mode');
      if (icon) {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
      }
    } else {
      document.body.classList.add('light-mode');
      if (icon) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
      }
    }
  });
}

// --- Upload drag & drop ---
const uploadArea = document.getElementById('upload-area');

if (uploadArea) {
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    uploadArea.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
  });

  ['dragenter', 'dragover'].forEach(eventName => {
    uploadArea.addEventListener(eventName, () => {
      uploadArea.classList.add('dragover');
    });
  });

  ['dragleave', 'drop'].forEach(eventName => {
    uploadArea.addEventListener(eventName, () => {
      uploadArea.classList.remove('dragover');
    });
  });

  uploadArea.addEventListener('drop', (e) => {
    const files = e.dataTransfer.files;
    handleFiles(files);
  });

  uploadArea.addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'video/*';
    input.onchange = (e) => handleFiles(e.target.files);
    input.click();
  });
}

function handleFiles(files) {
  if (!files.length) return;
  const uploadList = document.getElementById('upload-list');
  if (!uploadList) return;

  Array.from(files).forEach(async (file) => {
    const item = document.createElement('div');
    item.className = 'upload-item';
    const sizeMB = (file.size / 1024 / 1024).toFixed(1);
    item.innerHTML = `
      <div class="upload-thumb"><i class="fa-solid fa-film"></i></div>
      <div class="upload-details">
        <h4>${file.name}</h4>
        <p>${sizeMB} MB</p>
        <div class="upload-progress-bar">
          <div class="upload-progress-fill" style="width: 0%;"></div>
        </div>
      </div>
      <span class="upload-status">0%</span>
    `;
    uploadList.prepend(item);

    const fill = item.querySelector('.upload-progress-fill');
    const status = item.querySelector('.upload-status');

    try {
      const result = await API.uploadFile(file, null, (pct) => {
        const p = Math.round(pct * 90);
        if (fill) fill.style.width = p + '%';
        if (status) status.textContent = p + '%';
      });

      if (fill) fill.style.width = '95%';
      if (status) status.textContent = 'Indexing…';

      const videoId = result.video_id;
      if (videoId) {
        await API.ingest(videoId).catch(() => {});
        if (fill) fill.style.width = '100%';
        if (status) status.textContent = 'Done';
      }
    } catch (e) {
      if (status) status.textContent = 'Error: ' + e.message;
      if (fill) { fill.style.width = '100%'; fill.style.background = '#ef4444'; }
    }
  });
}

// --- Pricing toggle ---
const billingToggle = document.getElementById('billing-toggle');
const proPrice = document.getElementById('pro-price');
const teamPrice = document.getElementById('team-price');

if (billingToggle) {
  billingToggle.addEventListener('click', () => {
    billingToggle.classList.toggle('yearly');
    const isYearly = billingToggle.classList.contains('yearly');
    if (proPrice) proPrice.textContent = isYearly ? '$15' : '$19';
    if (teamPrice) teamPrice.textContent = isYearly ? '$39' : '$49';
  });
}

// --- Sidebar menu active state on current page ---
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
const sidebarMenuItems = document.querySelectorAll('.sidebar-menu .menu-item');
sidebarMenuItems.forEach(item => {
  const href = item.getAttribute('href');
  if (href === currentPage) {
    sidebarMenuItems.forEach(mi => mi.classList.remove('active'));
    item.classList.add('active');
  }
});

// --- Back to My Videos link ---
const backLink = document.querySelector('.back-link');
if (backLink) {
  backLink.setAttribute('href', 'my-videos.html');
}

// --- Upload New Video button ---
const btnUpload = document.querySelector('.btn-upload');
if (btnUpload) {
  btnUpload.addEventListener('click', () => {
    window.location.href = 'upload.html';
  });
}

// --- Settings page: section navigation ---
const settingsNavItems = document.querySelectorAll('.settings-nav-item');
const settingsSections = document.querySelectorAll('.settings-section');

settingsNavItems.forEach(navItem => {
  navItem.addEventListener('click', (e) => {
    e.preventDefault();
    settingsNavItems.forEach(n => n.classList.remove('active'));
    navItem.classList.add('active');
    settingsSections.forEach(s => s.classList.remove('active'));
    const target = navItem.dataset.section;
    const targetSection = document.getElementById(target);
    if (targetSection) targetSection.classList.add('active');
  });
});

// --- Settings page: toggle switches ---
const settingToggles = document.querySelectorAll('.settings-card .toggle-switch');

settingToggles.forEach(toggle => {
  toggle.addEventListener('click', () => {
    toggle.classList.toggle('active');
  });
});

console.log('ASKVGIA Dashboard Loaded');